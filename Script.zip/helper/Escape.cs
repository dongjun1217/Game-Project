﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Escape : MonoBehaviour {

	int timeLeft;
	public GameObject Player;
	public Transform Home;

	// Use this for initialization
	void Start () {
		timeLeft = 0;
	}
	
	// Update is called once per frame
	void Update () {
		
		if(timeLeft <= 5)
		{
			timeLeft++;
			if (timeLeft <= 6) {
				Player.transform.position = Home.position;
			}
	}
	}
}
