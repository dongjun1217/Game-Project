﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(CharacterStats))]
public class FireBall : MonoBehaviour {

	public Transform attackTarget;
	NavMeshAgent agent;
	Transform target;
	int attackCount = 0;
	CharacterStats c1;
	public event System.Action OnFireDamage;

	void Start () {
		target = PlayerManager.instance.player.transform;
		agent = GetComponent<NavMeshAgent> ();
		c1 = GetComponent<CharacterStats> ();
	}

	void Update(){
		if (attackCount < 10) {
			FaceTarget ();
			attackCount++;
		}
		if (attackCount >= 10) {
			agent.SetDestination (agent.transform.position += agent.transform.forward);
		}

		Invoke ("dieFireball", 2);
	}

	void FaceTarget()
	{
		Vector3 direction = (target.position - transform.position).normalized;
		Quaternion lookRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));
		transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * 5f);
	}

	void dieFireball(){
		Destroy (this.gameObject);
	}
		

	void OnTriggerStay(Collider collider)
	{
		collider.gameObject.GetComponent<CharacterStats> ().TakeDamage (8);
		Destroy (this.gameObject);
	}


}
