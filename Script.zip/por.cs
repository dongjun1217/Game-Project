﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class por : MonoBehaviour
{

    public Transform spawnpoint;
	public GameObject enemy;

	public Transform enemyTarget;
	int count=0;

    void OnTriggerStay(Collider collider)
	{
		collider.gameObject.transform.position = spawnpoint.position;
		if (count < 1) {
			Instantiate (enemy, new Vector3 (enemyTarget.position.x + Random.Range (1, 10), enemyTarget.position.y, enemyTarget.position.z + Random.Range (1, 10)), Quaternion.identity);
			count++;
		}
	}

	public void CountReset(){
		count = 0;
	}

}
