﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


public class DragonCombat : MonoBehaviour {

	public Animator anim;
	public float lookRadius = 10f;
	Transform target;
	NavMeshAgent agent;
	CharacterCombat combat;
	public GameObject fireBall;
	public Transform fireBall_Target;
	int count=0;
	int cooltime =175;
	int fbcount=0;

	void Start () {
		target = PlayerManager.instance.player.transform;
		agent = GetComponent<NavMeshAgent> ();
		combat = GetComponent<CharacterCombat> ();
		anim.Play ("Idle02");

	}

	void Update () {
		float distance = Vector3.Distance (target.position, transform.position);
		if (distance > lookRadius) {
			anim.Play ("Idle02");
			count = 0;
			fbcount = 0;
		}

		if (distance <= lookRadius) {
			if (count < cooltime) {
				anim.Play ("Scream");
				count++;
			}
			if (count >= cooltime) {
				FaceTarget ();
				anim.Play ("Flame Attack");
				Invoke ("FireBallCT", 1);
				Invoke ("FireBallBT", 8);
				Invoke ("ScreamCT", 1);
			}
				
		}

	}

	void ScreamCT(){
		count = 0;
	}

	void FireBallCT(){
		if (fbcount < 100) {
			Instantiate (fireBall, new Vector3 (fireBall_Target.position.x, fireBall_Target.position.y, fireBall_Target.position.z), Quaternion.identity);
			fbcount++;
		}
	}

	void FireBallBT(){
		fbcount = 0;
	}



	void FaceTarget(){
		Vector3 direction = (target.position - transform.position).normalized;
		Quaternion lookRotation = Quaternion.LookRotation (new Vector3 (direction.x, 0, direction.z));
		transform.rotation = Quaternion.Slerp (transform.rotation, lookRotation, Time.deltaTime * 5f);

	}

	void OnDrawGizmosSelected(){
		Gizmos.color = Color.red;
		Gizmos.DrawWireSphere (transform.position, lookRadius);
	}
}
