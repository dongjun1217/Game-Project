﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;

[RequireComponent(typeof(CharacterStats))]
public class PlayerHealthUI : MonoBehaviour {
	public GameObject uiPrefab;
	public Transform target;
	Transform ui;
	Image healthSlider;
	void Start () {

		foreach (Canvas c in FindObjectsOfType<Canvas>()) 
		{
			if (c.renderMode == RenderMode.ScreenSpaceOverlay) 
			{
				ui = Instantiate (uiPrefab, c.transform).transform;	
				healthSlider = ui.GetChild (0).GetComponent<Image> ();
				ui.gameObject.SetActive (true);
				break;
			}
		}
		GetComponent<CharacterStats> ().OnHealthChanged += OnHealthChanged;
	}

	void OnHealthChanged(int maxHealth , int currentHealth){
			float healthPercent = currentHealth / (float)maxHealth;
			healthSlider.fillAmount = healthPercent;
		}

}
