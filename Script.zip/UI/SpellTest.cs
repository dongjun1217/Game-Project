﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class SpellTest : MonoBehaviour {

	public GameObject spell;
	public int maxHealth = 100;
	public int currentHealth { get; private set; }
	public Stat heal;
	public event System.Action<int,int> OnHealthChanged;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Use () {

		if (Input.GetKeyDown (KeyCode.R)) {
			Instantiate (spell, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
			Takeheal (15);
		}
		
	}
	public void Takeheal(int heal)
	{

		heal = Mathf.Clamp(heal, 0, int.MaxValue);
		currentHealth += heal;
		Debug.Log(transform.name + "takes " + heal + " heal.");

		if (OnHealthChanged != null) 
		{
			OnHealthChanged (maxHealth, currentHealth);
		}

	}
}
