﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OpenUI : MonoBehaviour {

	public GameObject Op_UI;
	public GameObject MakerUI;

	// Use this for initialization
	void Start () {
		Op_UI.gameObject.SetActive (true);
	}

	public void GameStart(){
		Op_UI.gameObject.SetActive (false);
	}

	public void Maker(){
		Op_UI.gameObject.SetActive (false);
		MakerUI.gameObject.SetActive (true);
	}

	public void MakerBackButton(){
		MakerUI.gameObject.SetActive (false);
		Op_UI.gameObject.SetActive (true);
	}

}
