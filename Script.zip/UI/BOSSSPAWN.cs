﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class BOSSSPAWN : MonoBehaviour {

	public GameObject enemy;
	public Transform enemyTarget;
	public GameObject NPCUI;

	void Start () {
	}


	public void spawn(){
		Instantiate (enemy, new Vector3 (enemyTarget.position.x, enemyTarget.position.y, enemyTarget.position.z), Quaternion.identity);
		NPCUI.SetActive (false);
	}

	public void no(){
		NPCUI.SetActive (false);
	}

}
