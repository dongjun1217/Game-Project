﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;



public class SpellManager : MonoBehaviour {
	protected Animator animator;
	public GameObject SpellPrefab;
	public Transform target;
	float visiTime = 15;
	float lastvisiTime;
	Transform ui2;
	Image healspell;
	public GameObject[] spells;

	public void CastSpell(int curSpell)
	{
		spells [curSpell].GetComponent<Animator> ().SetTrigger ("activated");
	}

	void Start(){
		foreach (Canvas c in FindObjectsOfType<Canvas>()) {
			ui2 = Instantiate (SpellPrefab, c.transform).transform;
			healspell = ui2.GetChild (0).GetComponent<Image> ();

			break;

		}
	
	}
	void OnHealthChanged(int maxHealth , int currentHealth){
		if (Input.GetKeyDown (KeyCode.E))
		{
		ui2.gameObject.SetActive (false);
		}
	}
}
