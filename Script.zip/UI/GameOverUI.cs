﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOverUI : MonoBehaviour {

	public GameObject GO_UI;

	public void GameStart(){
		GO_UI.gameObject.SetActive (false);
	}

}
