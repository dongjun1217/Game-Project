﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterStats))]
public class Fireball1 : Interactable {

	CharacterStats fstat1;
	// Use this for initialization
	void Start () {
		fstat1 = GetComponent<CharacterStats> ();
	}
	
	void OnTriggerStay(Collider collider)
	{
		FireBall f1;
	}
}
