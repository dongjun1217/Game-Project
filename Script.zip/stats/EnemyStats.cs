﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : CharacterStats {
    public GameObject item1;





    void spawn()
    {
		Instantiate(item1, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
    }
    public override void Die()
    {
        base.Die();
        Destroy(gameObject);
        spawn();
    }
}
