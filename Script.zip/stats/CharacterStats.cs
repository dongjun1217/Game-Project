﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

using UnityEngine.AI;

public class CharacterStats : MonoBehaviour {

    public int maxHealth = 100;
    public int currentHealth { get; set; }
	public GameObject player;
    public Stat damage;
    public Stat armor;
	public GameObject spell;
	public Button HpButton;
	public event System.Action<int,int> OnHealthChanged;


    void Awake()
    {
        currentHealth = maxHealth;
    }
		
	void Update () {

		if (currentHealth <= 85) {
			if (Input.GetKeyDown (KeyCode.R)) {
				Instantiate (spell, new Vector3 (transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
				Takeheal (15);
			}
		}
	}
    public void TakeDamage(int damage)
    {

        damage -= armor.GetValue();
        damage = Mathf.Clamp(damage, 0, int.MaxValue);


        
        currentHealth -= damage;
        Debug.Log(transform.name + "takes " + damage + " damage.");

		if (OnHealthChanged != null) 
		{
			OnHealthChanged (maxHealth, currentHealth);
		}
        if(currentHealth <= 0)
        {
            Die();
        }
    }
	public void Takeheal(int heal)
	{

		heal = Mathf.Clamp(heal, 0, int.MaxValue);
		currentHealth += heal;
		Debug.Log(transform.name + "takes " + heal + " heal.");

		if (OnHealthChanged != null) 
		{
			OnHealthChanged (maxHealth, currentHealth);
		}

	}
	public void HealthUp(int str)
	{
		str = Mathf.Clamp (str, 0, int.MaxValue);
		maxHealth += str;
		currentHealth = maxHealth;

		if (OnHealthChanged != null) {
			OnHealthChanged (maxHealth, currentHealth);
		}
		Debug.Log (transform.name + "Takes " + str + "Health Up");
	}

	public void DamageUp(int dUp)
	{
		damage.AddModifier (dUp);
	}


    public virtual void Die()
    {
        Debug.Log(transform.name + "died.");
    }

}
