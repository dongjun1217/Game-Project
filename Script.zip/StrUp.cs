﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StrUp : MonoBehaviour {
	Stat damage;
	public Button buyButton;
	public Text Att;
	public int firstAtt=5;
	void Update(){

		Att.text = firstAtt.ToString ();
		if (GPTextScript.coinAmount >= 50)
			buyButton.interactable = true;
		else
			buyButton.interactable = false;
	}
	public void buyDamage(){
		GPTextScript.coinAmount -= 50;
		firstAtt += 1;
	}
}
