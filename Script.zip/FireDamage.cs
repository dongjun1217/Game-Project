﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireDamage : MonoBehaviour {

	public int maxHealth = 100;
	public int currentHealth { get; set; }
	public GameObject player;
	public Stat damage;
	public Stat armor;
	public event System.Action<int,int> OnHealthChanged;

	void Awake()
	{
		currentHealth = maxHealth;
	}

	public void TakeDamage(int damage)
	{

		damage -= armor.GetValue();
		damage = Mathf.Clamp(damage, 0, int.MaxValue);



		currentHealth -= damage;
		Debug.Log(transform.name + "takes " + damage + " damage.");

		if (OnHealthChanged != null) 
		{
			OnHealthChanged (maxHealth, currentHealth);
		}
		if(currentHealth <= 0)
		{
			Die();
		}
	}


	public virtual void Die()
	{
		Debug.Log(transform.name + "died.");
	}

	void OnTriggerStay(Collider collider)
	{
		currentHealth -= 15;
		Debug.Log(transform.name + "takes 15 damage.");

		if (OnHealthChanged != null) 
		{
			OnHealthChanged (maxHealth, currentHealth);
		}
		if(currentHealth <= 0)
		{
			Die();
		}

	}

}
