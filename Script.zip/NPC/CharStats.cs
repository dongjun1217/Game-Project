﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;

public class CharStats : MonoBehaviour {
	public GameObject ShopUI;
	public Text Hp;
	public Text Str;

	public Button buybutton;
	public int firstHp=100;
	public int firstStr=5;


	void Update () {
		Hp.text = firstHp.ToString();
		Str.text = firstStr.ToString();



		if (GPTextScript.coinAmount >= 50)
			buybutton.interactable = true;
		else
			buybutton.interactable = false;
	}

	public void buyStr()
	{
		GPTextScript.coinAmount -= 50;
		firstHp +=5;
		firstStr += 1;

	}



}
