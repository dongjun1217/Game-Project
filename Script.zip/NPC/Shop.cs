﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Shop : MonoBehaviour {


	public GameObject ShopUI;
	public Text Price;
	public Item Sword;
	public Item Shield;
	public Item Helmet;
	public Item Platebody;
	public Item Platelegs;
	public Button buybutton;
	void Update () {

		if (GPTextScript.coinAmount >= 5)
			buybutton.interactable = true;
		else
			buybutton.interactable = false;
	}

	public void buySword()
	{
		GPTextScript.coinAmount -= 10;
		Price.text = "BUY!";

		bool buying = Inventory.instance.Add (Sword);
	}
	public void buyShield()
	{
		GPTextScript.coinAmount -= 10;
		Price.text = "BUY!";

		bool buying = Inventory.instance.Add (Shield);
	}
	public void buyHelmet()
	{
		GPTextScript.coinAmount -= 10;
		Price.text = "BUY!";

		bool buying = Inventory.instance.Add (Helmet);
	}
	public void buyPlatelegs()
	{
		GPTextScript.coinAmount -= 10;
		Price.text = "BUY!";

		bool buying = Inventory.instance.Add (Platelegs);
	}
	public void buyPlatebody()
	{
		GPTextScript.coinAmount -= 10;
		Price.text = "BUY!";

		bool buying = Inventory.instance.Add (Platebody);
	}

	public void exitShop()
	{
		ShopUI.SetActive (false);
	}

	public void openShop()
	{
		ShopUI.SetActive (true);
	}

}
