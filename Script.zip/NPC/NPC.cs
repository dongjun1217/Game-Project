﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NPC : MonoBehaviour {

	public GameObject NPCKeyUI;
	public float UIActive = 0.5f;
	public GameObject SHOPUI;
	Transform target;


	// Use this for initialization
	void Start () {
		target = PlayerManager.instance.player.transform;
	}
		
	// Update is called once per frame
	void Update () {
		float distance = Vector3.Distance (target.position, transform.position);
		if (distance <= UIActive) {
			NPCKeyUI.SetActive (true);
			if (Input.GetKeyDown (KeyCode.F)) {
				SHOPUI.SetActive (true);
			}
		} else {
			NPCKeyUI.SetActive (false);
		}
	}
}
