﻿using UnityEngine;
using UnityEngine.UI;

public class GPTextScript : MonoBehaviour {

	Text text;

	public static int coinAmount;

	// Use this for initialization
	void Start () {
		coinAmount = 50;
		text = GetComponent<Text> ();

	}
	
	// Update is called once per frame
	void Update () {
		text.text = coinAmount.ToString ();
	}
		
}
