﻿using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName ="New BoxUse",menuName ="Inventory/BoxUse")]
public class BoxUse : Item {


	// Use this for initialization
	public override void Use()
	{
		base.Use();
		RemoveFromInventory();

		GPTextScript.coinAmount += Random.Range(30,100);

	}


}
