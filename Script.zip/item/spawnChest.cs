﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawnChest : MonoBehaviour {

    public GameObject item1;
    public GameObject item2;
    public GameObject item3;

    void spawnitem()
    {

        Instantiate(item1, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
        Instantiate(item2, new Vector3(transform.position.x+2, transform.position.y, transform.position.z), Quaternion.identity);
        Instantiate(item3, new Vector3(transform.position.x+4, transform.position.y, transform.position.z), Quaternion.identity);
    }

    void update()
    {
        Destroy(gameObject);
    }


}
